package com.example.commentapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.commentapplication.Adapter.ChatAdapter;
import com.example.commentapplication.Models.MessageModel;
import com.example.commentapplication.databinding.ActivityCommentBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class CommentActivity extends AppCompatActivity {
     ActivityCommentBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        final FirebaseDatabase database= FirebaseDatabase.getInstance();
        final ArrayList<MessageModel> MessageModel = new ArrayList<>();
        final String sendID = FirebaseAuth.getInstance().getUid();

        final ChatAdapter adapter = new ChatAdapter(MessageModel,this);
        binding.chatRecyclerView.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.chatRecyclerView.setLayoutManager(layoutManager);

        database.getReference().child("Comments").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                MessageModel.clear();
                for(DataSnapshot dataSnapshot: snapshot.getChildren())
                {
                    MessageModel model = dataSnapshot.getValue(com.example.commentapplication.Models.MessageModel.class);
                    MessageModel.add(model);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        binding.sent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Message = binding.enterMessage.getText().toString();
                final MessageModel Model = new MessageModel(sendID,Message);
                Model.setTimestamp(new Date().getTime());
                database.getReference().child("Comments")
                        .push()
                        .setValue(Model)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(CommentActivity.this, "Message Send", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
        binding.signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth mAuth = null;
                mAuth.signOut();
            }
        });

    }
    }



/*

                BottomSheetDialogFragment bottomSheetDialogFragment = new BottomSheetDialogFragment();
                bottomSheetDialogFragment.show(getSupportFragmentManager(),bottomSheetDialogFragment.getTag());
 */