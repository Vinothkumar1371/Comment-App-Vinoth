package com.example.commentapplication.Models;

public class Users {
    String email,password,UserID,secertkey;



    public Users()
    {

    }

    public Users(String email, String password, String secertkey,String UserID) {
        this.email = email;
        this.password = password;
        this.secertkey = secertkey;
        this.UserID = UserID;
    }

    public Users(String email, String password, String secertkey) {
        this.email = email;
        this.password = password;
        this.secertkey = secertkey;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getSecertkey() {
        return secertkey;
    }

    public void setSecertkey(String secertkey) {
        this.secertkey = secertkey;
    }
}
