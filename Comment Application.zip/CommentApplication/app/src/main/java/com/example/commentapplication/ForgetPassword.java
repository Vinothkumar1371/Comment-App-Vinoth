package com.example.commentapplication;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.commentapplication.databinding.ActivityForgetPasswordBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgetPassword extends AppCompatActivity {



    ActivityForgetPasswordBinding binding;

    private FirebaseAuth mAuth;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityForgetPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        progressDialog= new ProgressDialog(ForgetPassword.this);
        progressDialog.setTitle("Validating");
        progressDialog.setMessage("Validation Completed... Copy your password");
        mAuth = FirebaseAuth.getInstance();
        binding.verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!binding.forgetEmail.getText().toString().isEmpty())
                {
                    String email= binding.forgetEmail.getText().toString().trim();
                    mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if (task.isSuccessful())
                            {

                                Toast.makeText(ForgetPassword.this, "Check your email to reset your password", Toast.LENGTH_SHORT).show();
                                Intent Login = new Intent(ForgetPassword.this,login_activity.class);
                                startActivity(Login);
                                finish();
                            }
                            else
                            {
                                Toast.makeText(ForgetPassword.this, "Try Again Later", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                else
                {
                    Toast.makeText(ForgetPassword.this, "Enter the Valid Email Address", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}


/*
                    mAuth.signInWithEmailAndPassword(binding.forgetEmail.getText().toString(),binding.forgetSecert.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    progressDialog.dismiss();
                                    if(task.isSuccessful())
                                    {
                                        String id = task.getResult().getUser().getUid();
                                        binding.forgetEmail.setText("");
                                        binding.forgetSecert.setText("");
                                        DatabaseReference reference1;
                                        reference1=FirebaseDatabase.getInstance().getReference().child(id);
                                        reference1.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                String pass= snapshot.child("password").getValue().toString();
                                                Toast.makeText(ForgetPassword.this, pass, Toast.LENGTH_SHORT).show();
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {
                                                Toast.makeText(ForgetPassword.this, "Sorry,Can't get the Password", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                        binding.pass.setVisibility(View.VISIBLE);
                                        binding.copy.setVisibility(View.VISIBLE);

                                    }
                                    else
                                    {
                                        Toast.makeText(ForgetPassword.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
 */