package com.example.commentapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.commentapplication.Models.Users;
import com.example.commentapplication.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth =FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        progressDialog= new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Creating Account");
        progressDialog.setMessage("Your Account is created");
        binding.sloginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(MainActivity.this,login_activity.class);
                startActivity(LoginIntent);
                finish();
            }
        });
        binding.ssignupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!binding.signupEmail.getText().toString().isEmpty()&& !binding.signupPassword.getText().toString().isEmpty()&& !binding.signupSecert.getText().toString().isEmpty())
                {
                    progressDialog.show();
                    mAuth.createUserWithEmailAndPassword(binding.signupEmail.getText().toString(),binding.signupPassword.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    progressDialog.dismiss();

                                    if (task.isSuccessful())
                                    {
                                        Users user = new Users(binding.signupEmail.getText().toString(),binding.signupPassword.getText().toString(),binding.signupSecert.getText().toString());
                                        String id = task.getResult().getUser().getUid();
                                        database.getReference().child("User").child(id).setValue(user);
                                        Toast.makeText(MainActivity.this, "Signup Successfully", Toast.LENGTH_SHORT).show();
                                        binding.signupEmail.setText("");
                                        binding.signupPassword.setText("");
                                        binding.signupSecert.setText("");
                                        Intent Login = new Intent(MainActivity.this,login_activity.class);
                                        startActivity(Login);
                                        finish();
                                    }
                                    else
                                    {
                                        Toast.makeText(MainActivity.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                }
                else
                {
                    Toast.makeText(MainActivity.this, "Enter the all inputs", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}